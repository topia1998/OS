#include "threads/vaddr.h"
#include "devices/block.h"
#include "vm/swap.h"

void stack_growth(struct thread*, const void*);
